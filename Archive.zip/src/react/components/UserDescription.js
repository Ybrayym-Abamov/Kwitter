import React from "react";
// import { Link } from ".";
// import "./UserDescription.css";

class UserDescription extends React.Component {
    render() {
        return (
          <>
          Placeholder text for User Bio code. Bio will be input on UpdateUserForm. 
          </>
        );
      }
}
export default UserDescription;
