import React from "react";
// import { UserInfoBlock } from ".";
// import { Link } from ".";
// import "./UserList.css";

class UserList extends React.Component {
    render() {
        return (
          <>
            <p>This will be a feed of userinfoblocks for all registered users.</p>
            <p>can you imagine?</p>
            <p>a whole list of the currently registered users</p>
            <p>none of their kweets or messages or whatever</p>
            <p>but just a long, long list of all the test users everyone created during this assignment</p>
            <p>i bet it's a thing to behold</p>
            <p>"look at all the users I have. just look at them. here they are"</p>
          </>
        );
      }
}
export default UserList;
