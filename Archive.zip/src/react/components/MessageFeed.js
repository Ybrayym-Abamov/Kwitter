import React from "react";
import { Message } from ".";
// import "./MessageFeed.css";

class MessageFeed extends React.Component {
    render() {
        return (
        <>
              <Message />
        </>
        );
      }
}
export default MessageFeed;
