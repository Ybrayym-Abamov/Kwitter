import React from "react";
import { UpdateProfile } from "../components";
import 'antd/dist/antd.css';

class EditProfile extends React.Component {
    render() {
      return (  
        <UpdateProfile />
      );
    }
  }
  
  export default EditProfile;